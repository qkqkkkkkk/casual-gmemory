# Native GMemory + MacNet FEVER_binary_offline causal audit

- Held-out task-memory events: 240
- Recipients: solver_0, solver_2
- Primary outcome: exact FEVER binary-label accuracy
- Task: offline closed-book `SUPPORTS` / `REFUTES` classification

## RQ2: Global selective-memory value

| Policy | Memory Keep Rate ↓ | Seed 0 Team Accuracy ↑ | Seed 1000 Team Accuracy ↑ | Mean Team Accuracy ↑ | Δ vs Always Use [95% CI] ↑ | Oracle Gap Recovery ↑ |
|---|---:|---:|---:|---:|---:|---:|
| Always Use | 100.0% | 82.50% | 81.25% | 81.88% | — | 0.0% |
| Always Global Drop | 0.0% | 81.60% | 82.08% | 81.84% | -0.03 pp [-1.08, +1.04] | — |
| Random (budget matched) @ 5.6% | 5.6% | 81.66% | 82.05% | 81.85% | -0.02 pp [-1.01, +0.99] | -1.7% |
| Cross-run Selective Drop @ 5.6% | 5.6% | 82.64% | 82.85% | 82.74% | +0.87 pp [+0.10, +1.77] | 61.0% |
| Oracle Selective Drop @ 5.6% | 5.6% | 83.40% | 83.19% | 83.30% | +1.42 pp [+0.73, +2.26] | 100.0% |

Team Accuracy is exact FEVER label correctness. CIs are event-paired percentile-bootstrap intervals.
Random is the exact expected score of a uniform selector at the same keep budget as Oracle; it requires no extra rollout.
Cross-run Selective Drop applies each run's decisions to the other run. Oracle Selective Drop is a same-sample upper bound, not a deployable policy.

## RQ3: Recipient heterogeneity

- Intervention: isolated recipient exposure minus shared global-drop control
- Direct positive/negative recipient sign-flip rate: 1.25% [0.00, 2.92]
- Any recipient sign heterogeneity rate: 8.33% [5.00, 12.08]
- Mean within-event utility range: 0.02 [0.01, 0.04]

| Recipient | Mean utility [CI] | Positive | Neutral | Negative |
|---|---:|---:|---:|---:|
| solver_0 | 0.00 [-0.01, 0.01] | 8 | 222 | 10 |
| solver_2 | -0.00 [-0.01, 0.00] | 3 | 231 | 6 |

- Split-half reproducible recipient sign-flip rate: 0.00% [0.00, 0.00]

## RQ4: Objective local-to-team gap

- Local metric: FEVER gold evidence-page F1
- Team metric: exact FEVER binary-label accuracy
- Intervention: isolated exposure minus the same global-drop control
- Local/team sign-mismatch rate: 0.42% [0.00, 1.04]
- Split-half reproducible local/team mismatch rate: 0.00% [0.00, 0.00]
- Local/team utility correlation: -0.05 [-0.15, 0.02]

| Utility pattern | Event-clustered fraction [CI] |
|---|---:|
| Local +, Team + | 0.21% [0.00, 0.62] |
| Local +, Team - | 0.00% [0.00, 0.00] |
| Local -, Team + | 0.42% [0.00, 1.04] |
| Local -, Team - | 0.00% [0.00, 0.00] |
| Neutral involved | 99.38% [98.54, 100.00] |

The local metric scores predicted Wikipedia page titles against alternative gold FEVER evidence-page sets; it does not claim sentence-level evidence retrieval.

## Independent retest

- Shared events: 240
- RQ2 global utility sign consistency: 92.08% [88.33, 95.42]
- RQ2 bidirectional cross-run gain: 0.01 [0.00, 0.02]
- RQ3 recipient sign consistency: 94.79% [92.50, 96.88]
- RQ3 stable direct sign-flip rate: 0.00% [0.00, 0.00]
- RQ3 reproducible directional flip rate: 0.00% [0.00, 0.00]
- RQ4 local/team pattern agreement: 98.33% [97.08, 99.38]
- RQ4 cross-run directional mismatch rate: 0.21% [0.00, 0.62]
- RQ4 cross-run + split-half reproducible mismatch rate: 0.00% [0.00, 0.00]
