| method | Accuracy | Completion | Accuracy delta | 95% CI | keep rate | DROP tasks | improved | harmed |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| native_gmemory | 0.7800 | 0.7800 | +0.0000 | [0, 0] | 1.0000 | 0 | 0 | 0 |
| linear | 0.7800 | 0.7800 | +0.0000 | [0.0, 0.0] | 1.0000 | 0 | 0 | 0 |
| semantic_linear | 0.8000 | 0.8000 | +0.0200 | [-0.03, 0.07] | 0.8800 | 72 | 4 | 2 |
| semantic_mlp | 0.7800 | 0.7800 | +0.0000 | [0.0, 0.0] | 1.0000 | 0 | 0 | 0 |
