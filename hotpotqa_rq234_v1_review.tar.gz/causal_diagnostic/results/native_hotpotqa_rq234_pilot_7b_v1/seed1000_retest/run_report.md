# Native GMemory + MacNet HotpotQA causal audit

- Held-out question-memory events: 40
- Recipients: solver_0, solver_2
- Primary team outcome: official normalized answer token-F1
- Sensitivity outcome: normalized answer exact match
- Local outcome: supporting-fact F1 over (title, sentence index)
- Evaluation mode: offline with identical supplied context in every branch

## RQ2: Global selective-memory value

| Policy | Memory Keep Rate ↓ | Seed 0 Answer F1 ↑ | Seed 1000 Answer F1 ↑ | Mean Answer F1 ↑ | Δ vs Always Use [95% CI] ↑ | Oracle Gap Recovery ↑ |
|---|---:|---:|---:|---:|---:|---:|
| Always Use | 100.0% | 32.58% | 34.97% | 33.77% | — | 0.0% |
| Always Global Drop | 0.0% | 29.75% | 34.12% | 31.94% | -1.83 pp [-5.31, +1.34] | — |
| Random (budget matched) @ 38.8% | 38.8% | 30.81% | 34.46% | 32.64% | -1.14 pp [-3.25, +0.78] | -25.8% |
| Cross-run Selective Drop @ 38.8% | 38.8% | 29.98% | 34.04% | 32.01% | -1.76 pp [-4.04, +0.40] | -40.0% |
| Oracle Selective Drop @ 38.8% | 38.8% | 36.00% | 40.37% | 38.18% | +4.41 pp [+2.50, +6.72] | 100.0% |

### Answer exact-match sensitivity

| Policy | Memory Keep Rate ↓ | Seed 0 Answer EM ↑ | Seed 1000 Answer EM ↑ | Mean Answer EM ↑ | Δ vs Always Use [95% CI] ↑ | Oracle Gap Recovery ↑ |
|---|---:|---:|---:|---:|---:|---:|
| Always Use | 100.0% | 19.58% | 23.75% | 21.67% | — | 0.0% |
| Always Global Drop | 0.0% | 17.92% | 22.08% | 20.00% | -1.67 pp [-5.21, +1.46] | — |
| Random (budget matched) @ 21.3% | 21.3% | 18.29% | 22.42% | 20.35% | -1.31 pp [-3.98, +1.15] | -37.1% |
| Cross-run Selective Drop @ 21.3% | 21.3% | 17.50% | 22.08% | 19.79% | -1.88 pp [-4.17, +0.42] | -52.9% |
| Oracle Selective Drop @ 21.3% | 21.3% | 22.50% | 27.92% | 25.21% | +3.54 pp [+1.67, +5.83] | 100.0% |

### Final-decision supporting-fact sensitivity

| Policy | Memory Keep Rate ↓ | Seed 0 Supporting-fact F1 ↑ | Seed 1000 Supporting-fact F1 ↑ | Mean Supporting-fact F1 ↑ | Δ vs Always Use [95% CI] ↑ | Oracle Gap Recovery ↑ |
|---|---:|---:|---:|---:|---:|---:|
| Always Use | 100.0% | 18.54% | 16.74% | 17.64% | — | 0.0% |
| Always Global Drop | 0.0% | 15.86% | 15.00% | 15.43% | -2.21 pp [-4.94, +0.26] | — |
| Random (budget matched) @ 23.8% | 23.8% | 16.40% | 15.48% | 15.94% | -1.70 pp [-3.71, +0.21] | -91.8% |
| Cross-run Selective Drop @ 23.8% | 23.8% | 18.01% | 16.25% | 17.13% | -0.51 pp [-2.19, +1.26] | -27.3% |
| Oracle Selective Drop @ 23.8% | 23.8% | 19.47% | 19.51% | 19.49% | +1.85 pp [+0.76, +3.15] | 100.0% |

CIs use event-paired percentile bootstrap. Oracle Selective Drop is a same-sample upper bound; Cross-run Selective Drop is the independent-seed check.

## RQ3: Recipient heterogeneity

- Intervention: isolated recipient exposure minus the same global-drop control
- Direct positive/negative recipient sign-flip rate: 5.00% [0.00, 12.50]
- Any recipient sign heterogeneity rate: 27.50% [15.00, 42.50]
- Mean within-event answer-F1 utility range: 0.10 [0.06, 0.15]

| Recipient | Mean answer-F1 utility [CI] | Positive | Neutral | Negative |
|---|---:|---:|---:|---:|
| solver_0 | -0.06 [-0.13, -0.00] | 11 | 14 | 15 |
| solver_2 | -0.05 [-0.10, -0.00] | 11 | 15 | 14 |

- Split-half reproducible recipient sign-flip rate: 0.00% [0.00, 0.00]

## RQ4: Supporting-fact-to-answer gap

- Local/team sign-mismatch rate: 11.25% [3.75, 20.00]
- Split-half reproducible mismatch rate: 0.00% [0.00, 0.00]
- Local/team utility correlation: 0.12 [-0.28, 0.50]

| Pattern | Event-clustered fraction [CI] |
|---|---:|
| Local +, Team + | 5.00% [0.00, 11.25] |
| Local +, Team - | 5.00% [0.00, 11.25] |
| Local -, Team + | 6.25% [1.25, 13.75] |
| Local -, Team - | 3.75% [0.00, 8.75] |
| Neutral involved | 80.00% [68.75, 90.00] |

## Independent retest

- Shared events: 40
- RQ2 global-utility sign consistency: 40.00% [25.00, 55.00]
- RQ2 bidirectional cross-run gain: -0.02 [-0.04, 0.00]
- RQ3 recipient sign consistency: 48.75% [37.50, 61.25]
- RQ3 reproducible directional flip rate: 0.00% [0.00, 0.00]
- RQ4 local/team pattern agreement: 70.00% [57.50, 82.50]
