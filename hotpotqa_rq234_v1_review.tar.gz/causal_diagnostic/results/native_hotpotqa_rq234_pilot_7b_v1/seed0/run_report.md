# Native GMemory + MacNet HotpotQA causal audit

- Held-out question-memory events: 40
- Recipients: solver_0, solver_2
- Primary team outcome: official normalized answer token-F1
- Sensitivity outcome: normalized answer exact match
- Local outcome: supporting-fact F1 over (title, sentence index)
- Evaluation mode: offline with identical supplied context in every branch

## RQ2: Global selective-memory value

| Policy | Memory Keep Rate ↓ | Seed 0 Answer F1 ↑ | Δ vs Always Use [95% CI] ↑ | Oracle Gap Recovery ↑ |
|---|---:|---:|---:|---:|
| Always Use | 100.0% | 32.58% | — | 0.0% |
| Always Global Drop | 0.0% | 29.75% | -2.82 pp [-7.27, +1.75] | — |
| Random (budget matched) @ 37.5% | 37.5% | 30.81% | -1.76 pp [-4.72, +1.03] | -51.5% |
| Oracle Selective Drop @ 37.5% | 37.5% | 36.00% | +3.42 pp [+1.32, +6.07] | 100.0% |

### Answer exact-match sensitivity

| Policy | Memory Keep Rate ↓ | Seed 0 Answer EM ↑ | Δ vs Always Use [95% CI] ↑ | Oracle Gap Recovery ↑ |
|---|---:|---:|---:|---:|
| Always Use | 100.0% | 19.58% | — | 0.0% |
| Always Global Drop | 0.0% | 17.92% | -1.67 pp [-5.83, +2.08] | — |
| Random (budget matched) @ 22.5% | 22.5% | 18.29% | -1.29 pp [-4.52, +1.94] | -44.3% |
| Oracle Selective Drop @ 22.5% | 22.5% | 22.50% | +2.92 pp [+0.83, +5.42] | 100.0% |

### Final-decision supporting-fact sensitivity

| Policy | Memory Keep Rate ↓ | Seed 0 Supporting-fact F1 ↑ | Δ vs Always Use [95% CI] ↑ | Oracle Gap Recovery ↑ |
|---|---:|---:|---:|---:|
| Always Use | 100.0% | 18.54% | — | 0.0% |
| Always Global Drop | 0.0% | 15.86% | -2.68 pp [-5.83, +0.00] | — |
| Random (budget matched) @ 20.0% | 20.0% | 16.40% | -2.14 pp [-4.59, +0.02] | -230.4% |
| Oracle Selective Drop @ 20.0% | 20.0% | 19.47% | +0.93 pp [+0.17, +1.88] | 100.0% |

CIs use event-paired percentile bootstrap. Oracle Selective Drop is a same-sample upper bound; Cross-run Selective Drop is the independent-seed check.

## RQ3: Recipient heterogeneity

- Intervention: isolated recipient exposure minus the same global-drop control
- Direct positive/negative recipient sign-flip rate: 15.00% [5.00, 27.50]
- Any recipient sign heterogeneity rate: 52.50% [37.50, 67.50]
- Mean within-event answer-F1 utility range: 0.11 [0.07, 0.15]

| Recipient | Mean answer-F1 utility [CI] | Positive | Neutral | Negative |
|---|---:|---:|---:|---:|
| solver_0 | -0.02 [-0.06, 0.02] | 14 | 14 | 12 |
| solver_2 | 0.01 [-0.04, 0.05] | 11 | 19 | 10 |

- Split-half reproducible recipient sign-flip rate: 0.00% [0.00, 0.00]

## RQ4: Supporting-fact-to-answer gap

- Local/team sign-mismatch rate: 8.75% [2.50, 17.50]
- Split-half reproducible mismatch rate: 0.00% [0.00, 0.00]
- Local/team utility correlation: 0.10 [-0.00, 0.20]

| Pattern | Event-clustered fraction [CI] |
|---|---:|
| Local +, Team + | 7.50% [1.25, 15.00] |
| Local +, Team - | 5.00% [1.25, 10.00] |
| Local -, Team + | 3.75% [0.00, 8.75] |
| Local -, Team - | 6.25% [1.25, 11.25] |
| Neutral involved | 77.50% [66.25, 87.50] |

## Independent retest

Not available; run a disjoint inference-seed retest.
