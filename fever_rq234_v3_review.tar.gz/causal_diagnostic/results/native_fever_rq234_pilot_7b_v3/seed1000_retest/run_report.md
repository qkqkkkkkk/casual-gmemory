# Native GMemory + MacNet FEVER_binary_offline causal audit

- Held-out task-memory events: 40
- Recipients: solver_0, solver_2
- Primary outcome: exact FEVER binary-label accuracy
- Task: offline closed-book `SUPPORTS` / `REFUTES` classification

## RQ2: Global selective-memory value

| Policy | Memory Keep Rate ↓ | Seed 0 Team Accuracy ↑ | Seed 1000 Team Accuracy ↑ | Mean Team Accuracy ↑ | Δ vs Always Use [95% CI] ↑ | Oracle Gap Recovery ↑ |
|---|---:|---:|---:|---:|---:|---:|
| Always Use | 100.0% | 81.25% | 81.25% | 81.25% | — | 0.0% |
| Always Global Drop | 0.0% | 81.67% | 82.92% | 82.29% | +1.04 pp [-1.67, +3.54] | — |
| Random (budget matched) @ 3.8% | 3.8% | 81.66% | 82.83% | 82.24% | +0.99 pp [-1.42, +3.58] | 47.7% |
| Cross-run Selective Drop @ 3.8% | 3.8% | 82.50% | 83.75% | 83.12% | +1.88 pp [+0.21, +3.96] | 90.0% |
| Oracle Selective Drop @ 3.8% | 3.8% | 82.50% | 84.17% | 83.33% | +2.08 pp [+0.42, +4.17] | 100.0% |

Team Accuracy is exact FEVER label correctness. CIs are event-paired percentile-bootstrap intervals.
Random is the exact expected score of a uniform selector at the same keep budget as Oracle; it requires no extra rollout.
Cross-run Selective Drop applies each run's decisions to the other run. Oracle Selective Drop is a same-sample upper bound, not a deployable policy.

## RQ3: Recipient heterogeneity

- Intervention: isolated recipient exposure minus shared global-drop control
- Direct positive/negative recipient sign-flip rate: 0.00% [0.00, 0.00]
- Any recipient sign heterogeneity rate: 5.00% [0.00, 12.50]
- Mean within-event utility range: 0.02 [0.00, 0.04]

| Recipient | Mean utility [CI] | Positive | Neutral | Negative |
|---|---:|---:|---:|---:|
| solver_0 | -0.00 [-0.03, 0.02] | 1 | 36 | 3 |
| solver_2 | -0.01 [-0.03, 0.00] | 0 | 38 | 2 |

- Split-half reproducible recipient sign-flip rate: 0.00% [0.00, 0.00]

## RQ4: Objective local-to-team gap

- Local metric: FEVER gold evidence-page F1
- Team metric: exact FEVER binary-label accuracy
- Intervention: isolated exposure minus the same global-drop control
- Local/team sign-mismatch rate: 0.00% [0.00, 0.00]
- Split-half reproducible local/team mismatch rate: 0.00% [0.00, 0.00]
- Local/team utility correlation: -0.01 [-0.06, 0.03]

| Utility pattern | Event-clustered fraction [CI] |
|---|---:|
| Local +, Team + | 0.00% [0.00, 0.00] |
| Local +, Team - | 0.00% [0.00, 0.00] |
| Local -, Team + | 0.00% [0.00, 0.00] |
| Local -, Team - | 0.00% [0.00, 0.00] |
| Neutral involved | 100.00% [100.00, 100.00] |

The local metric scores predicted Wikipedia page titles against alternative gold FEVER evidence-page sets; it does not claim sentence-level evidence retrieval.

## Independent retest

- Shared events: 40
- RQ2 global utility sign consistency: 87.50% [77.50, 97.50]
- RQ2 bidirectional cross-run gain: 0.02 [0.00, 0.04]
- RQ3 recipient sign consistency: 95.00% [87.50, 100.00]
- RQ3 stable direct sign-flip rate: 0.00% [0.00, 0.00]
- RQ3 reproducible directional flip rate: 0.00% [0.00, 0.00]
- RQ4 local/team pattern agreement: 100.00% [100.00, 100.00]
- RQ4 cross-run directional mismatch rate: 0.00% [0.00, 0.00]
- RQ4 cross-run + split-half reproducible mismatch rate: 0.00% [0.00, 0.00]
