# Native GMemory + MacNet FEVER_binary_offline causal audit

- Held-out task-memory events: 40
- Recipients: solver_0, solver_2
- Primary outcome: exact FEVER binary-label accuracy
- Task: offline closed-book `SUPPORTS` / `REFUTES` classification

## RQ2: Global selective-memory value

| Policy | Memory Keep Rate ↓ | Seed 0 Team Accuracy ↑ | Δ vs Always Use [95% CI] ↑ | Oracle Gap Recovery ↑ |
|---|---:|---:|---:|---:|
| Always Use | 100.0% | 81.25% | — | 0.0% |
| Always Global Drop | 0.0% | 81.67% | +0.42 pp [-2.08, +2.92] | — |
| Random (budget matched) @ 2.5% | 2.5% | 81.66% | +0.41 pp [-2.03, +2.84] | 32.5% |
| Oracle Selective Drop @ 2.5% | 2.5% | 82.50% | +1.25 pp [+0.00, +3.33] | 100.0% |

Team Accuracy is exact FEVER label correctness. CIs are event-paired percentile-bootstrap intervals.
Random is the exact expected score of a uniform selector at the same keep budget as Oracle; it requires no extra rollout.
Cross-run Selective Drop applies each run's decisions to the other run. Oracle Selective Drop is a same-sample upper bound, not a deployable policy.

## RQ3: Recipient heterogeneity

- Intervention: isolated recipient exposure minus shared global-drop control
- Direct positive/negative recipient sign-flip rate: 0.00% [0.00, 0.00]
- Any recipient sign heterogeneity rate: 7.50% [0.00, 17.50]
- Mean within-event utility range: 0.02 [0.00, 0.05]

| Recipient | Mean utility [CI] | Positive | Neutral | Negative |
|---|---:|---:|---:|---:|
| solver_0 | 0.00 [-0.02, 0.03] | 2 | 37 | 1 |
| solver_2 | 0.00 [0.00, 0.00] | 0 | 40 | 0 |

- Split-half reproducible recipient sign-flip rate: 0.00% [0.00, 0.00]

## RQ4: Objective local-to-team gap

- Local metric: FEVER gold evidence-page F1
- Team metric: exact FEVER binary-label accuracy
- Intervention: isolated exposure minus the same global-drop control
- Local/team sign-mismatch rate: 0.00% [0.00, 0.00]
- Split-half reproducible local/team mismatch rate: 0.00% [0.00, 0.00]
- Local/team utility correlation: -0.01 [-0.05, 0.03]

| Utility pattern | Event-clustered fraction [CI] |
|---|---:|
| Local +, Team + | 0.00% [0.00, 0.00] |
| Local +, Team - | 0.00% [0.00, 0.00] |
| Local -, Team + | 0.00% [0.00, 0.00] |
| Local -, Team - | 0.00% [0.00, 0.00] |
| Neutral involved | 100.00% [100.00, 100.00] |

The local metric scores predicted Wikipedia page titles against alternative gold FEVER evidence-page sets; it does not claim sentence-level evidence retrieval.

## Independent retest

Not available. A disjoint inference-seed run is required before treating oracle decisions or recipient flips as replicated.
